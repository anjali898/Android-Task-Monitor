# Todo-List
An app to add your todo. 

You can add your todo list into the app set the time for it you will get reminder on the exact time. You can check the list as well as complete mark the list as complete once a task is been completed, delete the task if it is no required, edit it to make changes in the date, time, title etc. 

[task monitor.pdf](https://github.com/Anjali2023/Android_task_monitor/files/9110932/task.monitor.pdf)
